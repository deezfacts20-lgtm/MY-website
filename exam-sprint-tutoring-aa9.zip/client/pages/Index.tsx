import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Zap, BarChart3, Flame, BookOpen, Award, ChevronRight } from "lucide-react";

export default function Index() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-foreground">ExamSprint</h1>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/dashboard">
                <Button variant="ghost" className="text-foreground hover:text-primary">
                  Dashboard
                </Button>
              </Link>
              <Link to="/dashboard">
                <Button className="bg-primary hover:bg-primary/90 text-white">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-blue-50 via-purple-50 to-white pt-20 pb-32">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 right-0 w-80 h-80 bg-gradient-to-bl from-primary/20 to-transparent rounded-full blur-3xl" />
          <div className="absolute -bottom-40 left-0 w-80 h-80 bg-gradient-to-tr from-accent/20 to-transparent rounded-full blur-3xl" />
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-5xl md:text-6xl font-bold text-foreground mb-6 leading-tight">
                Master Your <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Exams</span> in Minutes
              </h2>
              <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
                Smart quizzes tailored for BECE, WASSCE, and University exams. Get instant feedback, track your progress, and ace your tests with ExamSprint.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/dashboard">
                  <Button size="lg" className="bg-primary hover:bg-primary/90 text-white w-full sm:w-auto gap-2">
                    Start Free Trial <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
                <Button size="lg" variant="outline" className="w-full sm:w-auto">
                  Learn More
                </Button>
              </div>
              <p className="text-sm text-muted-foreground mt-6">
                ✓ 3 Free quizzes daily · ✓ No credit card required · ✓ Join 10,000+ students
              </p>
            </div>
            <div className="relative">
              <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl p-8 border border-primary/20">
                <div className="space-y-4">
                  <div className="bg-white rounded-lg p-4 border border-border shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-foreground">WASSCE Math Quiz</span>
                      <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Completed</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-bold text-primary">8/10</span>
                      <span className="text-sm text-muted-foreground">80%</span>
                    </div>
                  </div>
                  <div className="bg-white rounded-lg p-4 border border-border shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-foreground">Biology: Photosynthesis</span>
                      <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded">In Progress</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-primary h-2 rounded-full" style={{width: '60%'}}></div>
                    </div>
                  </div>
                  <div className="bg-white rounded-lg p-4 border border-border shadow-sm">
                    <div className="text-sm font-medium text-foreground mb-2">Weekly Stats</div>
                    <div className="flex gap-2">
                      {[4, 6, 5, 8, 7, 9, 6].map((height, i) => (
                        <div key={i} className="flex-1 flex items-end gap-1">
                          <div 
                            className="w-full bg-gradient-to-t from-primary to-accent rounded-sm"
                            style={{height: `${height * 4}px`}}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">Why Choose ExamSprint?</h2>
            <p className="text-xl text-muted-foreground">Everything you need to prepare efficiently</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Zap,
                title: "Lightning-Fast Quizzes",
                description: "10-question quizzes tailored to your exam level and subject. Complete in just 10 minutes."
              },
              {
                icon: BarChart3,
                title: "Smart Performance Tracking",
                description: "See exactly where you excel and where you need improvement with detailed analytics."
              },
              {
                icon: Flame,
                title: "Study Streaks",
                description: "Build momentum with daily study streaks. Stay consistent and watch your progress grow."
              },
              {
                icon: BookOpen,
                title: "Expert Explanations",
                description: "Get instant feedback and detailed explanations for every question, not just correct answers."
              },
              {
                icon: Award,
                title: "Exam-Specific Content",
                description: "Practice with real exam questions covering BECE, WASSCE, and University curricula."
              },
              {
                icon: Zap,
                title: "No Ads, Just Learning",
                description: "Distraction-free environment designed to help you focus and prepare effectively."
              }
            ].map((feature, i) => {
              const Icon = feature.icon;
              return (
                <div key={i} className="p-6 border border-border rounded-xl hover:border-primary/50 hover:shadow-lg transition-all">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-accent/20 rounded-lg flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gradient-to-r from-primary/10 to-accent/10 border-y border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            {[
              { stat: "10,000+", label: "Active Students" },
              { stat: "50,000+", label: "Questions" },
              { stat: "3", label: "Exam Types" },
              { stat: "4.9★", label: "Average Rating" }
            ].map((item, i) => (
              <div key={i}>
                <p className="text-4xl font-bold text-primary mb-2">{item.stat}</p>
                <p className="text-muted-foreground">{item.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4">Simple, Transparent Pricing</h2>
            <p className="text-xl text-muted-foreground">Choose the plan that works for you</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Free Plan */}
            <div className="p-8 border border-border rounded-2xl">
              <h3 className="text-2xl font-bold text-foreground mb-2">Free Plan</h3>
              <p className="text-muted-foreground mb-6">Perfect to get started</p>
              <p className="text-4xl font-bold text-foreground mb-6">
                Free
              </p>
              <ul className="space-y-4 mb-8">
                {[
                  "3 quizzes per day",
                  "Basic topics",
                  "Instant scoring",
                  "Study streaks",
                  "Performance tracking"
                ].map((feature, i) => (
                  <li key={i} className="flex items-center gap-3 text-foreground">
                    <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center">
                      <div className="w-2 h-2 rounded-full bg-primary" />
                    </div>
                    {feature}
                  </li>
                ))}
              </ul>
              <Link to="/dashboard">
                <Button variant="outline" className="w-full">Get Started</Button>
              </Link>
            </div>

            {/* Premium Plan */}
            <div className="p-8 border-2 border-primary rounded-2xl relative overflow-hidden bg-gradient-to-br from-primary/5 to-accent/5">
              <div className="absolute top-0 right-0 bg-primary text-white px-4 py-1 text-sm font-semibold rounded-bl-lg">
                POPULAR
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-2">Premium Plan</h3>
              <p className="text-muted-foreground mb-6">For serious exam prep</p>
              <p className="text-4xl font-bold text-foreground mb-2">
                GHS 15-25
              </p>
              <p className="text-sm text-muted-foreground mb-6">/month, cancel anytime</p>
              <ul className="space-y-4 mb-8">
                {[
                  "Unlimited quizzes",
                  "All topics & subjects",
                  "Mock exams (50 questions)",
                  "AI-powered explanations",
                  "Advanced analytics",
                  "Priority support"
                ].map((feature, i) => (
                  <li key={i} className="flex items-center gap-3 text-foreground font-medium">
                    <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center">
                      <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    {feature}
                  </li>
                ))}
              </ul>
              <Link to="/dashboard">
                <Button className="w-full bg-primary hover:bg-primary/90 text-white gap-2">
                  Upgrade Now <ChevronRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary via-accent to-primary text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to ace your exams?</h2>
          <p className="text-xl text-white/90 mb-8">Start your free trial today. No credit card needed.</p>
          <Link to="/dashboard">
            <Button size="lg" className="bg-white text-primary hover:bg-gray-100 gap-2">
              Start Learning Now <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                  <Zap className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-lg font-bold">ExamSprint</h3>
              </div>
              <p className="text-white/70">Master your exams in minutes.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-white/70 text-sm">
                <li><a href="#" className="hover:text-white transition">Features</a></li>
                <li><a href="#" className="hover:text-white transition">Pricing</a></li>
                <li><a href="#" className="hover:text-white transition">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-white/70 text-sm">
                <li><a href="#" className="hover:text-white transition">About</a></li>
                <li><a href="#" className="hover:text-white transition">Blog</a></li>
                <li><a href="#" className="hover:text-white transition">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-white/70 text-sm">
                <li><a href="#" className="hover:text-white transition">Privacy</a></li>
                <li><a href="#" className="hover:text-white transition">Terms</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/20 pt-8 text-center text-white/70 text-sm">
            <p>&copy; 2024 ExamSprint. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
