import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Zap, LogOut, Flame, Award, TrendingUp, BookOpen, Cpu, Play, Settings } from "lucide-react";

const EXAM_TYPES = [
  { id: "bece", name: "BECE", description: "Basic Education Certificate" },
  { id: "wassce", name: "WASSCE", description: "West African Senior School Cert" },
  { id: "university", name: "University", description: "University Entrance" }
];

const SUBJECTS = {
  bece: [
    "English Language",
    "Mathematics",
    "Integrated Science",
    "Social Studies",
    "RME"
  ],
  wassce: [
    "English Language",
    "Mathematics",
    "Biology",
    "Chemistry",
    "Physics",
    "Economics"
  ],
  university: [
    "Mathematics",
    "Physics",
    "Chemistry",
    "Biology",
    "Computer Science",
    "Economics"
  ]
};

const TOPICS = {
  "Mathematics": ["Algebra", "Geometry", "Trigonometry", "Calculus", "Statistics"],
  "Physics": ["Mechanics", "Electricity", "Waves", "Thermodynamics", "Optics"],
  "Chemistry": ["Atomic Structure", "Bonding", "Reactions", "Organic Chemistry", "Solutions"],
  "Biology": ["Cell Biology", "Genetics", "Ecology", "Physiology", "Evolution"],
  "English Language": ["Grammar", "Comprehension", "Writing", "Literature", "Speaking"],
  "Computer Science": ["Programming", "Data Structures", "Algorithms", "Databases", "Networks"],
  "Economics": ["Microeconomics", "Macroeconomics", "Trade", "Finance", "Development"],
  "Integrated Science": ["Energy", "Matter", "Life", "Earth", "Health"],
  "Social Studies": ["Geography", "History", "Culture", "Governance", "Environment"],
  "RME": ["Christianity", "Islam", "African Religion", "Ethics", "Spirituality"]
};

export default function Dashboard() {
  const [selectedExam, setSelectedExam] = useState<string | null>(null);
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [quizStarted, setQuizStarted] = useState(false);

  const subjectOptions = selectedExam ? SUBJECTS[selectedExam as keyof typeof SUBJECTS] : [];
  const topicOptions = selectedSubject ? TOPICS[selectedSubject as keyof typeof TOPICS] || [] : [];

  const handleGenerateQuiz = () => {
    if (selectedExam && selectedSubject && selectedTopic) {
      setQuizStarted(true);
    }
  };

  if (quizStarted) {
    return <QuizInterface exam={selectedExam} subject={selectedSubject} topic={selectedTopic} onBack={() => setQuizStarted(false)} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <header className="bg-white border-b border-border sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-foreground">ExamSprint</h1>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/">
                <Button variant="ghost" size="sm" className="gap-2">
                  <LogOut className="w-4 h-4" />
                  Logout
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Welcome Section */}
        <div className="mb-10">
          <h2 className="text-4xl font-bold text-foreground mb-2">Welcome back, Student!</h2>
          <p className="text-muted-foreground">Select your exam type, subject, and topic to generate a quiz</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Sidebar - Quiz Generator */}
          <div className="lg:col-span-2 space-y-8">
            {/* Exam Selection */}
            <div className="bg-white rounded-xl border border-border p-6">
              <div className="flex items-center gap-2 mb-4">
                <BookOpen className="w-5 h-5 text-primary" />
                <h3 className="text-lg font-semibold text-foreground">Select Exam Type</h3>
              </div>
              <div className="grid sm:grid-cols-3 gap-4">
                {EXAM_TYPES.map(exam => (
                  <button
                    key={exam.id}
                    onClick={() => {
                      setSelectedExam(exam.id);
                      setSelectedSubject(null);
                      setSelectedTopic(null);
                    }}
                    className={`p-4 rounded-lg border-2 transition-all text-left ${
                      selectedExam === exam.id
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <p className="font-semibold text-foreground">{exam.name}</p>
                    <p className="text-sm text-muted-foreground">{exam.description}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Subject Selection */}
            {selectedExam && (
              <div className="bg-white rounded-xl border border-border p-6 animate-in fade-in slide-in-from-bottom-2">
                <div className="flex items-center gap-2 mb-4">
                  <Cpu className="w-5 h-5 text-primary" />
                  <h3 className="text-lg font-semibold text-foreground">Select Subject</h3>
                </div>
                <div className="grid sm:grid-cols-2 gap-3">
                  {subjectOptions.map(subject => (
                    <button
                      key={subject}
                      onClick={() => {
                        setSelectedSubject(subject);
                        setSelectedTopic(null);
                      }}
                      className={`p-4 rounded-lg border-2 transition-all text-left ${
                        selectedSubject === subject
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <p className="font-medium text-foreground">{subject}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Topic Selection */}
            {selectedSubject && (
              <div className="bg-white rounded-xl border border-border p-6 animate-in fade-in slide-in-from-bottom-2">
                <div className="flex items-center gap-2 mb-4">
                  <Award className="w-5 h-5 text-primary" />
                  <h3 className="text-lg font-semibold text-foreground">Select Topic</h3>
                </div>
                <div className="grid sm:grid-cols-2 gap-3">
                  {topicOptions.map(topic => (
                    <button
                      key={topic}
                      onClick={() => setSelectedTopic(topic)}
                      className={`p-4 rounded-lg border-2 transition-all text-left ${
                        selectedTopic === topic
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <p className="font-medium text-foreground">{topic}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Generate Quiz Button */}
            {selectedTopic && (
              <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-xl border border-primary/20 p-6 animate-in fade-in slide-in-from-bottom-2">
                <p className="text-sm text-muted-foreground mb-4">
                  Ready to test your knowledge?
                </p>
                <Button
                  onClick={handleGenerateQuiz}
                  size="lg"
                  className="w-full bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90 text-white gap-2"
                >
                  <Play className="w-5 h-5" />
                  Generate 10-Question Quiz
                </Button>
              </div>
            )}
          </div>

          {/* Right Sidebar - Stats */}
          <div className="space-y-6">
            {/* Study Streak */}
            <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-xl border border-orange-200 p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-red-400 rounded-lg flex items-center justify-center">
                  <Flame className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Study Streak</p>
                  <p className="text-3xl font-bold text-foreground">7 days</p>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">Keep it up! One more quiz to extend your streak.</p>
            </div>

            {/* Performance Overview */}
            <div className="bg-white rounded-xl border border-border p-6">
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="w-5 h-5 text-primary" />
                <h3 className="font-semibold text-foreground">Performance</h3>
              </div>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Quizzes Taken</p>
                  <p className="text-3xl font-bold text-foreground">24</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Average Score</p>
                  <p className="text-3xl font-bold text-primary">78%</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Weak Area</p>
                  <p className="text-sm font-medium text-foreground">Chemistry: Organic</p>
                </div>
              </div>
            </div>

            {/* Premium CTA */}
            <div className="bg-gradient-to-br from-primary/20 to-accent/20 rounded-xl border border-primary/30 p-6">
              <h3 className="font-semibold text-foreground mb-2">Unlock Premium</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Get unlimited quizzes, mock exams, and AI explanations.
              </p>
              <Button className="w-full bg-primary hover:bg-primary/90 text-white">
                Upgrade Now
              </Button>
            </div>

            {/* Quick Stats */}
            <div className="bg-white rounded-xl border border-border p-6">
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Today</span>
                  <span className="font-medium text-foreground">2 quizzes</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">This Week</span>
                  <span className="font-medium text-foreground">12 quizzes</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Best Score</span>
                  <span className="font-medium text-foreground">95%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

interface QuizInterfaceProps {
  exam: string | null;
  subject: string | null;
  topic: string | null;
  onBack: () => void;
}

function QuizInterface({ exam, subject, topic, onBack }: QuizInterfaceProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [showResults, setShowResults] = useState(false);

  // Mock quiz data
  const questions = [
    {
      question: "What is the primary function of " + topic + " in " + subject + "?",
      options: ["Option A", "Option B", "Option C", "Option D"],
      correct: 0,
      explanation: "This is the correct answer because..."
    },
    {
      question: "Which of the following best describes the concept?",
      options: ["Definition A", "Definition B", "Definition C", "Definition D"],
      correct: 1,
      explanation: "The correct definition is..."
    },
    {
      question: "In the context of " + topic + ", what is the relationship between two concepts?",
      options: ["Relationship A", "Relationship B", "Relationship C", "Relationship D"],
      correct: 2,
      explanation: "The relationship is..."
    },
    {
      question: "Which application of " + topic + " is most relevant to real-world scenarios?",
      options: ["Application A", "Application B", "Application C", "Application D"],
      correct: 0,
      explanation: "This application is most relevant because..."
    },
    {
      question: "What are the key components of this concept?",
      options: ["Component Set A", "Component Set B", "Component Set C", "Component Set D"],
      correct: 3,
      explanation: "The key components are..."
    },
    {
      question: "How does this topic relate to other areas of " + subject + "?",
      options: ["Relation A", "Relation B", "Relation C", "Relation D"],
      correct: 1,
      explanation: "The relationship is established through..."
    },
    {
      question: "What is a common misconception about this topic?",
      options: ["Misconception A", "Misconception B", "Misconception C", "Misconception D"],
      correct: 2,
      explanation: "A common misconception is..."
    },
    {
      question: "In an exam context, which scenario would require knowledge of this topic?",
      options: ["Scenario A", "Scenario B", "Scenario C", "Scenario D"],
      correct: 0,
      explanation: "This scenario requires..."
    },
    {
      question: "What is the historical context or development of this concept?",
      options: ["History A", "History B", "History C", "History D"],
      correct: 3,
      explanation: "The historical development shows..."
    },
    {
      question: "Which of the following is an advanced application of this topic?",
      options: ["Advanced A", "Advanced B", "Advanced C", "Advanced D"],
      correct: 1,
      explanation: "This advanced application demonstrates..."
    }
  ];

  const handleAnswer = (optionIndex: number) => {
    setAnswers(prev => ({
      ...prev,
      [currentQuestion]: optionIndex.toString()
    }));
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResults(true);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const score = Object.entries(answers).filter(
    ([idx, ans]) => parseInt(ans) === questions[parseInt(idx)].correct
  ).length;

  if (showResults) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
        <header className="bg-white border-b border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-foreground">ExamSprint</h1>
            </div>
          </div>
        </header>

        <main className="max-w-2xl mx-auto px-4 py-20">
          <div className="text-center mb-10">
            <div className="w-20 h-20 bg-gradient-to-br from-green-400 to-primary rounded-full flex items-center justify-center mx-auto mb-6">
              <Award className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-4xl font-bold text-foreground mb-4">Quiz Completed!</h2>
            <p className="text-lg text-muted-foreground mb-8">Here's your performance report</p>
          </div>

          <div className="bg-white rounded-xl border border-border p-8 mb-8">
            <div className="grid grid-cols-3 gap-6 mb-8">
              <div className="text-center">
                <p className="text-5xl font-bold text-primary">{score}</p>
                <p className="text-muted-foreground">Correct Answers</p>
              </div>
              <div className="text-center">
                <p className="text-5xl font-bold text-green-600">{Math.round(score/10 * 100)}%</p>
                <p className="text-muted-foreground">Score</p>
              </div>
              <div className="text-center">
                <p className="text-5xl font-bold text-muted-foreground">{10 - score}</p>
                <p className="text-muted-foreground">Incorrect</p>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="font-semibold text-foreground mb-4">Summary</h3>
              {questions.map((q, idx) => (
                <div key={idx} className={`p-4 rounded-lg border ${
                  parseInt(answers[idx] || '-1') === q.correct
                    ? 'bg-green-50 border-green-200'
                    : 'bg-red-50 border-red-200'
                }`}>
                  <div className="flex items-start gap-3 mb-2">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center mt-0.5 flex-shrink-0 ${
                      parseInt(answers[idx] || '-1') === q.correct
                        ? 'bg-green-500 text-white'
                        : 'bg-red-500 text-white'
                    }`}>
                      {parseInt(answers[idx] || '-1') === q.correct ? '✓' : '✗'}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-foreground text-sm">Question {idx + 1}</p>
                      <p className="text-sm text-muted-foreground mt-1">{q.explanation}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-4">
            <Button onClick={onBack} variant="outline" className="flex-1">
              Back to Dashboard
            </Button>
            <Button className="flex-1 bg-primary hover:bg-primary/90 text-white">
              Review Weak Areas
            </Button>
          </div>
        </main>
      </div>
    );
  }

  const question = questions[currentQuestion];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <header className="bg-white border-b border-border sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-foreground">ExamSprint</h1>
            </div>
            <Button onClick={onBack} variant="ghost" size="sm">Exit Quiz</Button>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">Question {currentQuestion + 1} of {questions.length}</p>
            <div className="w-32 h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-primary to-accent transition-all"
                style={{width: `${(currentQuestion + 1) / questions.length * 100}%`}}
              />
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-10">
        <div className="bg-white rounded-xl border border-border p-8 mb-8">
          <h2 className="text-2xl font-bold text-foreground mb-8">{question.question}</h2>
          
          <div className="space-y-3 mb-8">
            {question.options.map((option, idx) => (
              <button
                key={idx}
                onClick={() => handleAnswer(idx)}
                className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                  parseInt(answers[currentQuestion] || '-1') === idx
                    ? 'border-primary bg-primary/5'
                    : 'border-border hover:border-primary/50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                    parseInt(answers[currentQuestion] || '-1') === idx
                      ? 'border-primary bg-primary'
                      : 'border-border'
                  }`}>
                    {parseInt(answers[currentQuestion] || '-1') === idx && (
                      <div className="w-2 h-2 rounded-full bg-white" />
                    )}
                  </div>
                  <span className="font-medium text-foreground">{option}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="flex gap-4">
          <Button 
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
            variant="outline"
            className="flex-1"
          >
            Previous
          </Button>
          <Button 
            onClick={handleNext}
            className="flex-1 bg-primary hover:bg-primary/90 text-white"
          >
            {currentQuestion === questions.length - 1 ? 'Finish' : 'Next'}
          </Button>
        </div>
      </main>
    </div>
  );
}
